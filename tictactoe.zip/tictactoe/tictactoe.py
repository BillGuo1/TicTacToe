"""
Tic Tac Toe Player
"""
import copy
import math

X = "X"
O = "O"
EMPTY = None



def initial_state():
    """
    Returns starting state of the board.
    """
    return [[EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY]]


def player(board):
    """
    Returns player who has the next turn on a board.
    """
    x = 0
    o = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] == X:
                x+=1
            elif board[i][j] == O:
                o+=1
    if x == o:
        return X
    elif x == o + 1:
        return O


def actions(board):
    """
    Returns set of all possible actions (i, j) available on the board.
    """
    boxes = []
    for i in range(3):
        for j in range(3):
            if board[i][j] is None:
                boxes.append([i, j])
    return boxes


def result(board, action, player):
    """
    Returns the board that results from making move (i, j) on the board.
    """
    b = board
    b[action[0]][action[1]] = player
    return b


def winner(board):
    """
    Returns the winner of the game, if there is one.
    """
    for i in range(3):
        if board[i][0] == board[i][1] and board[i][0] == board[i][2] and board[i][0] is not EMPTY:
            if board[i][0] == X:
                return X
            else:
                return O
        if board[0][i] == board[1][i] and board[0][i] == board[2][i] and board[0][i] is not EMPTY:
            if board[0][i] == X:
                return X
            else:
                return O
    if board[0][0] == board[1][1] and board[0][0] == board[2][2] and board[0][0] is not EMPTY:
        if board[0][0] == X:
            return X
        else:
            return O
    if board[0][2] == board[1][1] and board[1][1] == board[2][0] and board[1][1] is not EMPTY:
        if board[1][1] == X:
            return X
        else:
            return O
    return None

def terminal(board):
    """
    Returns True if game is over, False otherwise.
    """
    if len(actions(board)) == 0:
        return True
    if utility(board) == 0:
        return False
    return True


def utility(board):
    """
    Returns 1 if X has won the game, -1 if O has won, 0 otherwise.
    """
    side = winner(board)
    if side is not None:
        if side == X:
            return 1
        else:
            return -1
    else:
        return 0


def minimax(board):
    """
    Returns the optimal action for the current player on the board.
    """
    queue = actions(board)
    side = player(board)
    other_side = player(board)
    if player(board) == X:
        other_side = O
    else:
        other_side = X
    for i in range(len(queue)):
        move = queue[i]
        temp_board = copy.deepcopy(board)
        if winner(result(temp_board, move, side)) == side:
            return move
    for i in range(len(queue)):
        move = queue[i]
        temp_board = copy.deepcopy(board)
        if winner(result(temp_board, move, other_side)) == other_side:
            return move
    if len(queue) == 8:
        move = [1, 1]
        return move
    if len(queue) == 7:
        for i in range(len(queue)):
            move = queue[i]
            if (move[0] == 0 or move[0] == 2) and (move[1] == 0 or move[1] == 2):
                return move
    for i in range(len(queue)):
        move = queue[i]
        temp_board = copy.deepcopy(board)
        new_board = result(temp_board, move, side)
        for move in actions(new_board):
            if utility(result(new_board, move, other_side)) != 0:
                break
        return move